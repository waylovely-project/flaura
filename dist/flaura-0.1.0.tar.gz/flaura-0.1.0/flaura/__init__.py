import click 
from .group import OrderedGroup 

@click.group(cls=OrderedGroup)
def flaura():
    pass